using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class Designations : System.Web.UI.Page
{
    Designations_B b1 = new Designations_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    static string str = "";
  
    static int col;
  
    protected void Page_Load(object sender, EventArgs e)
    {
	
        if (Session.IsNewSession)
        {
           // Response.Redirect("Default.aspx");
        }
        

        if (this.IsPostBack)
        {
 	   
            return;
        }
        else
	{
            MasterData.SelectCommand = MasterGridBind();
	}
    }

  
    protected string MasterGridBind(string Extra = "")
    {
        b1.M_Extra = Extra;
        ds = b1.MasterGrid();
        return str = ds.Tables[0].Rows[0][0].ToString();
    }

   
    protected void btnAdd_Click(object sender, EventArgs e)
    {

        Response.Redirect("DesignationsAdd.aspx");
    }

    protected void MasterGrid_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect("DesignationsEdit.aspx?MasterId=" + MasterGrid.SelectedRow.Cells[1].Text);
    }

}

