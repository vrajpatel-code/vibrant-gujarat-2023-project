﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class viewrequestform : System.Web.UI.Page
{
    Students_B b1 = new Students_B();
    Requests_B r1 = new Requests_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();  

        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request.QueryString["rid"];
            fetch(id);
        }
        public void fetch(string id)
        {
            b1.M_StudentId = Convert.ToInt64(id);
            DataSet ds = b1.StudentsEdit();

            StudentName.Text = ds.Tables[0].Rows[0]["StudentName"].ToString();
            MeritNo.Text = ds.Tables[0].Rows[0]["MeritNo"].ToString();
            Semester.Text = ds.Tables[0].Rows[0]["Semester"].ToString();
            InstitiuteId.Text = ds.Tables[0].Rows[0]["InstitiuteId"].ToString();
            DepartmentId.Text = ds.Tables[0].Rows[0]["DepartmentId"].ToString();
            ReasonofTransfer.Text =ds.Tables[0].Rows[0]["ReasonofTransfer"].ToString();
            OtherParticular.Text = ds.Tables[0].Rows[0]["OtherParticular"].ToString();

        }
    }