﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Approve : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (this.IsPostBack)
        {

            return;
        }
        int stid;

        if (Session["did"].ToString() == "1")
        {
            stid = 3;
        }
        else if (Session["did"].ToString() == "2")
        {
            stid = 5;
        }
        else if (Session["did"].ToString() == "3")
        {
            stid = 7;
        }
        else { stid = 1; }
        StID.Text = Convert.ToString(stid);
    }
}