using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class ModulesEdit : System.Web.UI.Page
{
    Modules_B b1 = new Modules_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
    static string ExtraQry = "";
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.IsNewSession)
        {
           // Response.Redirect("Default.aspx");
        }

     

        if (this.IsPostBack)
        {
            return;
        }
       
        lblMasterId.Text = Request.QueryString["MasterId"];        
        FetchRecord(lblMasterId.Text);   

    }

    

    protected void FetchRecord(string MasterId)
    {
        try
        { 
            b1.M_ModuleId = CO.ToInt64(MasterId);
            ds = b1.ModulesEdit();
            txtModuleName.Text=CO.ToString(ds.Tables[0].Rows[0]["ModuleName"]);

        }
        catch (Exception ex)
        {  
        }

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try 
        {
            b1.M_ModuleId = CO.ToInt64(lblMasterId.Text);  
             b1.M_ModuleName = CO.ToString(txtModuleName.Text);

            b1.ModulesUpdate();              
            Response.Redirect("Modules.aspx");
        }
        catch (Exception ex)
        {
            
        }
    }

   
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            b1.M_ModuleId = CO.ToInt64(lblMasterId.Text);
            b1.ModulesDelete();
           Response.Redirect("Modules.aspx");
        }
        catch (Exception ex)
        { 
        }
    }

   
    
}

