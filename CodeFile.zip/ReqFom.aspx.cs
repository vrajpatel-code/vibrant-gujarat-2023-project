﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ReqFom : System.Web.UI.Page
{
    Students_B b1 = new Students_B();
    Requests_B r1 = new Requests_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();


    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=students;Integrated Security=True");
        con.Open();
        SqlDataAdapter sel = new SqlDataAdapter("SELECT RequestId FROM Requests WHERE StudentId='" + Session["id"].ToString() + "' ", con);
        DataTable dt = new DataTable();
        //sel.Fill(dt);
        //if (dt.)
        //{
        //    Response.Redirect("Status.aspx");
        //}
        string id = Session["id"].ToString();
        fetch(id);
    }
    public void fetch(string id)
    {
        b1.M_StudentId = Convert.ToInt64(id);
        DataSet ds = b1.StudentsEdit();
        StudentName.Text = ds.Tables[0].Rows[0]["StudentName"].ToString();
        MeritNo.Text = ds.Tables[0].Rows[0]["MeritNo"].ToString();
        Semester.Text = ds.Tables[0].Rows[0]["Semester"].ToString();
        InstitiuteId.Text = ds.Tables[0].Rows[0]["InstitiuteId"].ToString();
        DepartmentId.Text = ds.Tables[0].Rows[0]["DepartmentId"].ToString();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (ReasonofTransfer.Text != "")
        {
            r1.M_StudentId =  CO.ToInt64(Session["id"].ToString());
            r1.M_CurrentYear = DateTime.Today.Year.ToString();
            r1.M_Semester = CO.ToString(Semester.Text);
            r1.M_ReasonofTransfer = CO.ToString(ReasonofTransfer.Text);
            r1.M_OtherParticular = CO.ToString(OtherParticular.Text);
            r1.M_Approve1 = CO.ToInt64("0");
            r1.M_StatusId = 1;
            ds = r1.RequestsAdd();

            Response.Redirect("DocsUpload.aspx ?rid ="+ ds.Tables[0].Rows[0][0].ToString());
        }
        else {
            alert.Text = "Please Enter Reason Of Transfer";
        }
    }
}