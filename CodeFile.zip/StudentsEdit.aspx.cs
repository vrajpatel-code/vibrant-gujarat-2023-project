using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class StudentsEdit : System.Web.UI.Page
{
    Students_B b1 = new Students_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
    static string ExtraQry = "";
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.IsNewSession)
        {
           // Response.Redirect("Default.aspx");
        }

     

        if (this.IsPostBack)
        {
            return;
        }
       
        lblMasterId.Text = Request.QueryString["MasterId"];        
        FetchRecord(lblMasterId.Text);   

    }

    

    protected void FetchRecord(string MasterId)
    {
        try
        { 
            b1.M_StudentId = CO.ToInt64(MasterId);
            ds = b1.StudentsEdit();
            txtStudentName.Text=CO.ToString(ds.Tables[0].Rows[0]["StudentName"]);
            txtInstitiuteId.Text=CO.ToString(ds.Tables[0].Rows[0]["InstitiuteId"]);
            txtDepartmentId.Text=CO.ToString(ds.Tables[0].Rows[0]["DepartmentId"]);
            txtSemester.Text=CO.ToString(ds.Tables[0].Rows[0]["Semester"]);
            txtYear.Text=CO.ToString(ds.Tables[0].Rows[0]["Year"]);
            txtGender.Text=CO.ToString(ds.Tables[0].Rows[0]["Gender"]);
            txtEmailId.Text=CO.ToString(ds.Tables[0].Rows[0]["EmailId"]);
            txtContactNo.Text=CO.ToString(ds.Tables[0].Rows[0]["ContactNo"]);
            txtMeritNo.Text=CO.ToString(ds.Tables[0].Rows[0]["MeritNo"]);
            txtPassword.Text=CO.ToString(ds.Tables[0].Rows[0]["Password"]);

        }
        catch (Exception ex)
        {  
        }

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try 
        {
            b1.M_StudentId = CO.ToInt64(lblMasterId.Text);  
             b1.M_StudentName = CO.ToString(txtStudentName.Text);
             b1.M_InstitiuteId = CO.ToInt64(txtInstitiuteId.SelectedValue);
             b1.M_DepartmentId = CO.ToInt64(txtDepartmentId.SelectedValue);
             b1.M_Semester = CO.ToInt64(txtSemester.Text);
             b1.M_Year = CO.ToString(txtYear.Text);
             b1.M_Gender = CO.ToInt64(txtGender.Text);
             b1.M_EmailId = CO.ToString(txtEmailId.SelectedValue);
             b1.M_ContactNo = CO.ToString(txtContactNo.Text);
             b1.M_MeritNo = CO.ToString(txtMeritNo.Text);
             b1.M_Password = CO.ToString(txtPassword.Text);

            b1.StudentsUpdate();              
            Response.Redirect("Students.aspx");
        }
        catch (Exception ex)
        {
            
        }
    }

   
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            b1.M_StudentId = CO.ToInt64(lblMasterId.Text);
            b1.StudentsDelete();
           Response.Redirect("Students.aspx");
        }
        catch (Exception ex)
        { 
        }
    }

   
    
}

