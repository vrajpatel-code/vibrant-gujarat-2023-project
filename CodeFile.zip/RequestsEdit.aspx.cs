using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class RequestsEdit : System.Web.UI.Page
{
    Requests_B b1 = new Requests_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
 
    string str = "";   
    static int col;
    static string ExtraQry = "";
  
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session.IsNewSession)
        {
            Response.Redirect("Default.aspx");
        }

      
        if (this.IsPostBack)
        {
            return;
        }
       
        lblMasterId.Text = Request.QueryString["MasterId"];        
        FetchRecord(lblMasterId.Text);  
	DetailGridBind(lblMasterId.Text);  
 	
    }

    

    protected void FetchRecord(string MasterId)
    {
        try
        { 
            b1.M_RequestId = CO.ToInt64(MasterId);
            ds = b1.RequestsEdit();
            txtStudentId.Text=CO.ToString(ds.Tables[0].Rows[0]["StudentId"]);
            txtCurrentYear.Text=CO.ToString(ds.Tables[0].Rows[0]["CurrentYear"]);
            txtSemester.Text=CO.ToString(ds.Tables[0].Rows[0]["Semester"]);
            txtReasonofTransfer.Text=CO.ToString(ds.Tables[0].Rows[0]["ReasonofTransfer"]);
            txtOtherParticular.Text=CO.ToString(ds.Tables[0].Rows[0]["OtherParticular"]);
            txtApprove1.Text=CO.ToString(ds.Tables[0].Rows[0]["Approve1"]);
            txtStatusId.Text=CO.ToString(ds.Tables[0].Rows[0]["StatusId"]);
            txtAddmissionLetter.Text=CO.ToString(ds.Tables[0].Rows[0]["AddmissionLetter"]);
            txtIdentiyCard.Text=CO.ToString(ds.Tables[0].Rows[0]["IdentiyCard"]);
            txtFeeReceipt.Text=CO.ToString(ds.Tables[0].Rows[0]["FeeReceipt"]);
            txtMedicalCertificate.Text=CO.ToString(ds.Tables[0].Rows[0]["MedicalCertificate"]);
            txtMarksheet.Text=CO.ToString(ds.Tables[0].Rows[0]["Marksheet"]);
            txtDeathCertificate.Text=CO.ToString(ds.Tables[0].Rows[0]["DeathCertificate"]);


        }
        catch (Exception ex)
        {  
         }

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try 
        {
            b1.M_RequestId = CO.ToInt64(lblMasterId.Text);  
          
             b1.M_StudentId = CO.ToInt64(txtStudentId.SelectedValue);
             b1.M_CurrentYear = CO.ToString(txtCurrentYear.Text);
             b1.M_Semester = CO.ToString(txtSemester.Text);
             b1.M_ReasonofTransfer = CO.ToString(txtReasonofTransfer.Text);
             b1.M_OtherParticular = CO.ToString(txtOtherParticular.Text);
             b1.M_Approve1 = CO.ToInt64(txtApprove1.Text);
             b1.M_StatusId = CO.ToInt64(txtStatusId.SelectedValue);
             b1.M_AddmissionLetter = CO.ToString(txtAddmissionLetter.Text);
             b1.M_IdentiyCard = CO.ToString(txtIdentiyCard.Text);
             b1.M_FeeReceipt = CO.ToString(txtFeeReceipt.Text);
             b1.M_MedicalCertificate = CO.ToString(txtMedicalCertificate.Text);
             b1.M_Marksheet = CO.ToString(txtMarksheet.Text);
             b1.M_DeathCertificate = CO.ToString(txtDeathCertificate.Text);


            b1.RequestsUpdate();              
           Response.Redirect(  "Requests.aspx");   
        }
        catch (Exception ex)
        {           
          
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
       Response.Redirect(Request.RawUrl);
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            b1.M_RequestId = CO.ToInt64(lblMasterId.Text);
            b1.RequestsDelete();
           Response.Redirect(  "Requests.aspx"); 
        }
        catch (Exception ex)
        { 
	}

    }


    protected void DetailGrid_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect(  "RequestsDetailEdit.aspx?MasterId=" + lblMasterId.Text + "&DetailId=" + DetailGrid.SelectedRow.Cells[1].Text);
    }

  

    protected void btnDetailAdd_Click(object sender, EventArgs e)
    {
        Response.Redirect( "RequestsDetailAdd.aspx?MasterId=" + lblMasterId.Text);
    }
    protected void DetailGridBind(string Extra = "")
    {
        b1.M_Extra = " and RequestId=" + Extra;
        ds = b1.DetailGrid();
        str = ds.Tables[0].Rows[0][0].ToString();
        DetailData.SelectCommand = str;
        DetailData.DataBind();
    }
   

   protected void btnDetailDelete_Click(object sender, EventArgs e)
    { try
       {
        for (int i = 0; i < DetailGrid.Rows.Count; i++)
        {
           
                int id = CO.ToInt32(DetailGrid.Rows[i].Cells[1].Text.ToString());

                CheckBox chkDelete1 = (CheckBox)DetailGrid.Rows[i].FindControl("chkDelete");
                if (chkDelete1.Checked == true)
                {
			b1.M_RequestId = CO.ToInt64(lblMasterId.Text);
            		b1.D_RequestDetId = CO.ToInt64(id);
            		b1.RequestsDetailDelete();
                }
          }
      
        DetailGridBind(lblMasterId.Text);
       }
    catch (Exception ex)
    { 
       }
    }

 
}


