﻿
Partial Class StudentGridview
    Inherits System.Web.UI.Page

End Class
