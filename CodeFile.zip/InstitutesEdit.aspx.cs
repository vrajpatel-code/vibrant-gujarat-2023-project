using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class InstitutesEdit : System.Web.UI.Page
{
    Institutes_B b1 = new Institutes_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
 
    string str = "";   
    static int col;
    static string ExtraQry = "";
  
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session.IsNewSession)
        {
            Response.Redirect("Default.aspx");
        }

      
        if (this.IsPostBack)
        {
            return;
        }
       
        lblMasterId.Text = Request.QueryString["MasterId"];        
        FetchRecord(lblMasterId.Text);  
	DetailGridBind(lblMasterId.Text);  
 	
    }

    

    protected void FetchRecord(string MasterId)
    {
        try
        { 
            b1.M_InstituteId = CO.ToInt64(MasterId);
            ds = b1.InstitutesEdit();
            txtInstituteName.Text=CO.ToString(ds.Tables[0].Rows[0]["InstituteName"]);
            txtInstituteAddress.Text=CO.ToString(ds.Tables[0].Rows[0]["InstituteAddress"]);
            txtContactNo.Text=CO.ToString(ds.Tables[0].Rows[0]["ContactNo"]);
            txtEmail.Text=CO.ToString(ds.Tables[0].Rows[0]["Email"]);
            txtWebsite.Text=CO.ToString(ds.Tables[0].Rows[0]["Website"]);


        }
        catch (Exception ex)
        {  
         }

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try 
        {
            b1.M_InstituteId = CO.ToInt64(lblMasterId.Text);  
          
             b1.M_InstituteName = CO.ToString(txtInstituteName.Text);
             b1.M_InstituteAddress = CO.ToString(txtInstituteAddress.Text);
             b1.M_ContactNo = CO.ToString(txtContactNo.Text);
             b1.M_Email = CO.ToString(txtEmail.Text);
             b1.M_Website = CO.ToString(txtWebsite.Text);


            b1.InstitutesUpdate();              
            
        }
        catch (Exception ex)
        {           
          
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
       Response.Redirect(Request.RawUrl);
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            b1.M_InstituteId = CO.ToInt64(lblMasterId.Text);
            b1.InstitutesDelete();
           
        }
        catch (Exception ex)
        { 
	}

    }


    protected void DetailGrid_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect(  "InstitutesDetailEdit.aspx?MasterId=" + lblMasterId.Text + "&DetailId=" + DetailGrid.SelectedRow.Cells[1].Text);
    }

  

    protected void btnDetailAdd_Click(object sender, EventArgs e)
    {
        Response.Redirect( "InstitutesDetailAdd.aspx?MasterId=" + lblMasterId.Text);
    }
    protected void DetailGridBind(string Extra = "")
    {
        b1.M_Extra = " and InstituteId=" + Extra;
        ds = b1.DetailGrid();
        str = ds.Tables[0].Rows[0][0].ToString();
        DetailData.SelectCommand = str;
        DetailData.DataBind();
    }
   

   protected void btnDetailDelete_Click(object sender, EventArgs e)
    { try
       {
        for (int i = 0; i < DetailGrid.Rows.Count; i++)
        {
           
                int id = CO.ToInt32(DetailGrid.Rows[i].Cells[1].Text.ToString());

                CheckBox chkDelete1 = (CheckBox)DetailGrid.Rows[i].FindControl("chkDelete");
                if (chkDelete1.Checked == true)
                {
			b1.M_InstituteId = CO.ToInt64(lblMasterId.Text);
            		b1.D_InstituteDepartmentId = CO.ToInt64(id);
            		b1.InstitutesDetailDelete();
                }
          }
      
        DetailGridBind(lblMasterId.Text);
       }
    catch (Exception ex)
    { 
       }
    }

 
}


