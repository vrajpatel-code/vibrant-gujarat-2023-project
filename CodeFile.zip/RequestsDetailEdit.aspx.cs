using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class RequestsDetailEdit : System.Web.UI.Page
{
    Requests_B b1 = new Requests_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();


    protected void Page_Load(object sender, EventArgs e)
    {
	
         if (Session.IsNewSession)
        {
           // Response.Redirect("Default.aspx");
        }

    
        if (this.IsPostBack)
        {
            return;
        }
        lblMasterId.Text = Request.QueryString["MasterId"];
        lblDetailId.Text = Request.QueryString["DetailId"];    
        FetchRecord(lblDetailId.Text);
    }
   

        protected void FetchRecord(string DetailId)
    {
        try
        {   b1.M_RequestId = CO.ToInt64(lblMasterId.Text);
            b1.D_RequestDetId = CO.ToInt64(DetailId);
            ds = b1.RequestsDetailEdit();
txtInstituteId.Text=CO.ToString(ds.Tables[0].Rows[0]["InstituteId"]);
txtDeptId.Text=CO.ToString(ds.Tables[0].Rows[0]["DeptId"]);

        }
        catch (Exception ex)
        {  
         
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try 
        {
	    b1.M_RequestId = CO.ToInt64(lblMasterId.Text);
            b1.D_RequestDetId = CO.ToInt64(lblDetailId.Text); 
            
             b1.D_InstituteId = CO.ToInt64(txtInstituteId.SelectedValue);
             b1.D_DeptId = CO.ToInt64(txtDeptId.SelectedValue);


            b1.RequestsDetailUpdate();              
	    
        }
        catch (Exception ex)
        {
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
     	Response.Redirect(Request.RawUrl);      
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
	    b1.M_RequestId = CO.ToInt64(lblMasterId.Text);
            b1.D_RequestDetId = CO.ToInt64(lblDetailId.Text);
            b1.RequestsDetailDelete();
        }
        catch (Exception ex)
        { 
       
        }
    }

}

