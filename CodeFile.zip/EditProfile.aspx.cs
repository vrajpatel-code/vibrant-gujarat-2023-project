﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class EditProfile : System.Web.UI.Page
{
    Students_B b1 = new Students_B();
    Common CO = new Common();


    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            return;
        }



        string id;
        if (Request.QueryString["id"] == null)
        {
            id = Session["id"].ToString();
        }
        else
        {
            id = Request.QueryString["id"];
        }
        fetch(id);
    }
    protected void UP_Click(object sender, EventArgs e)
    {
 
    }
    public void fetch(string id)
    {
        b1.M_StudentId = Convert.ToInt64(id);
        DataSet ds = b1.StudentsEdit();
        StudentName.Text = ds.Tables[0].Rows[0]["StudentName"].ToString();
        EnrollNo.Text = ds.Tables[0].Rows[0]["EnrollNo"].ToString();
        EmailId.Text = ds.Tables[0].Rows[0]["EmailId"].ToString();
        Gender.SelectedValue = ds.Tables[0].Rows[0]["Gender"].ToString();
        ContactNo.Text = ds.Tables[0].Rows[0]["ContactNo"].ToString();
        MeritNo.Text = ds.Tables[0].Rows[0]["MeritNo"].ToString();
        Semester.Text = ds.Tables[0].Rows[0]["Semester"].ToString();
        InstitiuteId.SelectedValue = ds.Tables[0].Rows[0]["InstitiuteId"].ToString();
        DepartmentId.SelectedValue = ds.Tables[0].Rows[0]["DepartmentId"].ToString();
        Year.Text = ds.Tables[0].Rows[0]["Year"].ToString();
        Password.Text = ds.Tables[0].Rows[0]["Password"].ToString();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        b1.M_StudentId = Convert.ToInt64(Request.QueryString["id"]);
        b1.StudentsDelete();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string id;
        if (Request.QueryString["id"] == null)
        {
            id = Session["id"].ToString();
        }
        else
        {
            id = Request.QueryString["id"];
        }
        b1.M_StudentId = CO.ToInt64(id);
        b1.M_EnrollNo = EnrollNo.Text;
        b1.M_StudentName = StudentName.Text;
        b1.M_EmailId = EmailId.Text;
        b1.M_Gender = CO.ToInt64(Gender.SelectedValue);
        b1.M_ContactNo = ContactNo.Text;
        b1.M_MeritNo = MeritNo.Text;
        b1.M_Semester = CO.ToInt64(Semester.Text);
        b1.M_InstitiuteId = CO.ToInt64(InstitiuteId.SelectedValue);
        b1.M_DepartmentId = CO.ToInt64(DepartmentId.SelectedValue);
        b1.M_Password = Password.Text;
        b1.M_Year = Year.Text;
        b1.StudentsUpdate();
        if (Request.QueryString["id"] != null)
        {
            Response.Redirect("Home.aspx");
        }
        else
        {
            Response.Redirect("Home.aspx");
        }
    }
}