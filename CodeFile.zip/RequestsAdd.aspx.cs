using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class RequestsAdd : System.Web.UI.Page
{
    Requests_B b1 = new Requests_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
   
    protected void Page_Load(object sender, EventArgs e)
    {
	
    
        if (this.IsPostBack)
        {
            return;
        }
	
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
             b1.M_StudentId = CO.ToInt64(txtStudentId.SelectedValue);
             b1.M_CurrentYear = CO.ToString(txtCurrentYear.Text);
             b1.M_Semester = CO.ToString(txtSemester.Text);
             b1.M_ReasonofTransfer = CO.ToString(txtReasonofTransfer.Text);
             b1.M_OtherParticular = CO.ToString(txtOtherParticular.Text);
             b1.M_Approve1 = CO.ToInt64(txtApprove1.Text);
             b1.M_StatusId = CO.ToInt64(txtStatusId.SelectedValue);
             b1.M_AddmissionLetter = CO.ToString(txtAddmissionLetter.Text);
             b1.M_IdentiyCard = CO.ToString(txtIdentiyCard.Text);
             b1.M_FeeReceipt = CO.ToString(txtFeeReceipt.Text);
             b1.M_MedicalCertificate = CO.ToString(txtMedicalCertificate.Text);
             b1.M_Marksheet = CO.ToString(txtMarksheet.Text);
             b1.M_DeathCertificate = CO.ToString(txtDeathCertificate.Text);

            ds = b1.RequestsAdd();
            lblMasterId.Text = ds.Tables[0].Rows[0][0].ToString();
            Response.Redirect("Requests.aspx");
        }
        catch (Exception ex)
        {
         
        }
        
    }

  
}

