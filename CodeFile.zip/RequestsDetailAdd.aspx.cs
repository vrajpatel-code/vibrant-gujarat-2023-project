using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class RequestsDetailAdd : System.Web.UI.Page
{
    Requests_B b1 = new Requests_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
  

    protected void Page_Load(object sender, EventArgs e)
    {

         if (Session.IsNewSession)
        {
           // Response.Redirect("Default.aspx");
        }

       
        if (this.IsPostBack)
        {
            return;
        }

        lblMasterId.Text = Request.QueryString["MasterId"];
        
    }

    

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
b1.M_RequestId = CO.ToInt64(lblMasterId.Text);
             b1.D_InstituteId = CO.ToInt64(txtInstituteId.SelectedValue);
             b1.D_DeptId = CO.ToInt64(txtDeptId.SelectedValue);

            ds = b1.RequestsDetailAdd();
            lblDetailId.Text = ds.Tables[0].Rows[0][0].ToString();
	  
        }
        catch (Exception ex)
        {
           
        }
    }

  
}

