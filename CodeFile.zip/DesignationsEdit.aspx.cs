using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class DesignationsEdit : System.Web.UI.Page
{
    Designations_B b1 = new Designations_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
    static string ExtraQry = "";
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.IsNewSession)
        {
           // Response.Redirect("Default.aspx");
        }

     

        if (this.IsPostBack)
        {
            return;
        }
       
        lblMasterId.Text = Request.QueryString["MasterId"];        
        FetchRecord(lblMasterId.Text);   

    }

    

    protected void FetchRecord(string MasterId)
    {
        try
        { 
            b1.M_DesignationId = CO.ToInt64(MasterId);
            ds = b1.DesignationsEdit();
            txtDesignationName.Text=CO.ToString(ds.Tables[0].Rows[0]["DesignationName"]);

        }
        catch (Exception ex)
        {  
        }

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try 
        {
            b1.M_DesignationId = CO.ToInt64(lblMasterId.Text);  
             b1.M_DesignationName = CO.ToString(txtDesignationName.Text);

            b1.DesignationsUpdate();              
            Response.Redirect("Designations.aspx");
        }
        catch (Exception ex)
        {
            
        }
    }

   
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            b1.M_DesignationId = CO.ToInt64(lblMasterId.Text);
            b1.DesignationsDelete();
           Response.Redirect("Designations.aspx");
        }
        catch (Exception ex)
        { 
        }
    }

   
    
}

