using System;
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public class RequestsDetail_B : System.Web.UI.Page
{
    Common CO = new Common(); //M
    SqlDataReader dr;

	public RequestsDetail_B()
	{
		// TODO: Add constructor logic here
	}

    public string M_Extra { get; set; }
    
    public Int64 M_RequestId{ get; set; }
    public Int64 M_StudentId{ get; set; }
    public string M_CurrentYear{ get; set; }
    public string M_Semester{ get; set; }
    public string M_ReasonofTransfer{ get; set; }
    public string M_OtherParticular{ get; set; }
    public Int64 M_Approve1{ get; set; }
    public Int64 M_StatusId{ get; set; }
    public string M_AddmissionLetter{ get; set; }
    public string M_IdentiyCard{ get; set; }
    public string M_FeeReceipt{ get; set; }
    public string M_MedicalCertificate{ get; set; }
    public string M_Marksheet{ get; set; }
    public string M_DeathCertificate{ get; set; }

   

    

    


    

    




    public DataSet RequestsDetailAdd()
    {
        SqlParameter[] param = {  new SqlParameter("@addby",Session["userid"].ToString()),
                                 
    new SqlParameter("@StudentId",M_StudentId),
    new SqlParameter("@CurrentYear",M_CurrentYear),
    new SqlParameter("@Semester",M_Semester),
    new SqlParameter("@ReasonofTransfer",M_ReasonofTransfer),
    new SqlParameter("@OtherParticular",M_OtherParticular),
    new SqlParameter("@Approve1",M_Approve1),
    new SqlParameter("@StatusId",M_StatusId),
    new SqlParameter("@AddmissionLetter",M_AddmissionLetter),
    new SqlParameter("@IdentiyCard",M_IdentiyCard),
    new SqlParameter("@FeeReceipt",M_FeeReceipt),
    new SqlParameter("@MedicalCertificate",M_MedicalCertificate),
    new SqlParameter("@Marksheet",M_Marksheet),
    new SqlParameter("@DeathCertificate",M_DeathCertificate)
                               };

        return CO.RunProcDS("RequestsDetailAdd_SP", param);
    }
    
    public DataSet RequestsDetailSimpleAdd()
    {
        SqlParameter[] param = {                                   
                                  

                               };

        return CO.RunProcDS("RequestsDetailSimpleAdd_SP", param);
    }
    

    public DataSet RequestsDetailEdit()
    {
        SqlParameter[] param = { 
                               new SqlParameter("@RequestId", SqlDbType.BigInt),
                                };
        param[0].Value = M_RequestId;
        return CO.RunProcDS("RequestsDetailEdit_SP", param);
    }

   
  
    public void RequestsDetailUpdate()
    {
        SqlParameter[] param = { 
	new SqlParameter("@RequestId",M_RequestId),
                                 
    new SqlParameter("@StudentId",M_StudentId),
    new SqlParameter("@CurrentYear",M_CurrentYear),
    new SqlParameter("@Semester",M_Semester),
    new SqlParameter("@ReasonofTransfer",M_ReasonofTransfer),
    new SqlParameter("@OtherParticular",M_OtherParticular),
    new SqlParameter("@Approve1",M_Approve1),
    new SqlParameter("@StatusId",M_StatusId),
    new SqlParameter("@AddmissionLetter",M_AddmissionLetter),
    new SqlParameter("@IdentiyCard",M_IdentiyCard),
    new SqlParameter("@FeeReceipt",M_FeeReceipt),
    new SqlParameter("@MedicalCertificate",M_MedicalCertificate),
    new SqlParameter("@Marksheet",M_Marksheet),
    new SqlParameter("@DeathCertificate",M_DeathCertificate)
                               };

        CO.RunProc("RequestsDetailUpdate_SP",param,0);
    }


    public void RequestsDetailDelete()
    {
	SqlParameter[] param = { new SqlParameter("@RequestId", SqlDbType.BigInt)
 };  
         param[0].Value = M_RequestId;
        CO.RunProc("RequestsDetailDelete_SP",param,0);      
    }

    public DataSet MasterGrid()
    {       
        SqlParameter[] param = { 
                               new SqlParameter("@Extra", M_Extra)
                                };       
        return CO.RunProcDS("RequestsDetailGrid_SP", param);        
    }
}

