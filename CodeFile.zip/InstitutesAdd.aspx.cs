using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class InstitutesAdd : System.Web.UI.Page
{
    Institutes_B b1 = new Institutes_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
   
    protected void Page_Load(object sender, EventArgs e)
    {
	
    
        if (this.IsPostBack)
        {
            return;
        }
	
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
             b1.M_InstituteName = CO.ToString(txtInstituteName.Text);
             b1.M_InstituteAddress = CO.ToString(txtInstituteAddress.Text);
             b1.M_ContactNo = CO.ToString(txtContactNo.Text);
             b1.M_Email = CO.ToString(txtEmail.Text);
             b1.M_Website = CO.ToString(txtWebsite.Text);

            ds = b1.InstitutesAdd();
            lblMasterId.Text = ds.Tables[0].Rows[0][0].ToString();
            Response.Redirect("Institutes.aspx");
        }
        catch (Exception ex)
        {
         
        }
        
    }

  
}

