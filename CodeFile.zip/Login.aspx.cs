﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=students;Integrated Security=True");
        con.Open();
        SqlDataAdapter sel = new SqlDataAdapter("SELECT StudentId,Password FROM Students WHERE EnrollNo='" + UN.Text + "' ", con);
        DataTable dt = new DataTable();
        sel.Fill(dt);
        if (dt.Rows[0]["Password"].ToString() == Pass.Text)
        {
            Session["id"] = dt.Rows[0]["StudentId"].ToString();
            Response.Redirect("Home.aspx");

        }
        else
        {
            UN.Text = "";
            Pass.Text = "";

        }


    }
}