using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class DesignationsAdd : System.Web.UI.Page
{
    Designations_B b1 = new Designations_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
   
    protected void Page_Load(object sender, EventArgs e)
    {
	
    
        if (this.IsPostBack)
        {
            return;
        }
	
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
             b1.M_DesignationName = CO.ToString(txtDesignationName.Text);

            ds = b1.DesignationsAdd();
            lblMasterId.Text = ds.Tables[0].Rows[0][0].ToString();
           
        }
        catch (Exception ex)
        {
         
        }
        
    }

  
}

