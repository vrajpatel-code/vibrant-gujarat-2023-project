﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class DepartmentLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
     protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=students;Integrated Security=True");
        con.Open();
        SqlDataAdapter sel = new SqlDataAdapter("SELECT  UserId,Username,Password,DesignationId FROM Users WHERE Password ='" + Pass.Text + "'", con);
        DataTable dt = new DataTable();
        sel.Fill(dt);
        if (dt.Rows.Count >= 1)
        {
            if (dt.Rows[0]["Password"].ToString() == Pass.Text)
            {
                
                Session["did"] = dt.Rows[0]["DesignationId"].ToString();
                if (dt.Rows[0]["DesignationId"].ToString() == "4") {
                    Response.Redirect("Docter.aspx");
                }
                Response.Redirect("Requests.aspx");

            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Please Enter Valid Detail !!');", true);
            }
        }
        else
        {
            UN.Text = "";
            Pass.Text = "";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('No Data Found !!');", true);

        }


    }
}
