using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class UsersEdit : System.Web.UI.Page
{
    Users_B b1 = new Users_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
    static string ExtraQry = "";
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.IsNewSession)
        {
           // Response.Redirect("Default.aspx");
        }

     

        if (this.IsPostBack)
        {
            return;
        }
       
        lblMasterId.Text = Request.QueryString["MasterId"];        
        FetchRecord(lblMasterId.Text);   

    }

    

    protected void FetchRecord(string MasterId)
    {
        try
        { 
            b1.M_UserId = CO.ToInt64(MasterId);
            ds = b1.UsersEdit();
            txtUsername.Text=CO.ToString(ds.Tables[0].Rows[0]["Username"]);
            txtPassword.Text=CO.ToString(ds.Tables[0].Rows[0]["Password"]);
            txtUserFullName.Text=CO.ToString(ds.Tables[0].Rows[0]["UserFullName"]);
            txtEmailId.Text=CO.ToString(ds.Tables[0].Rows[0]["EmailId"]);
            txtInstituteId.Text=CO.ToString(ds.Tables[0].Rows[0]["InstituteId"]);
            txtDepartmentId.Text=CO.ToString(ds.Tables[0].Rows[0]["DepartmentId"]);
            txtDesignationId.Text=CO.ToString(ds.Tables[0].Rows[0]["DesignationId"]);
            txtRollId.Text=CO.ToString(ds.Tables[0].Rows[0]["RollId"]);

        }
        catch (Exception ex)
        {  
        }

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try 
        {
            b1.M_UserId = CO.ToInt64(lblMasterId.Text);  
             b1.M_Username = CO.ToString(txtUsername.Text);
             b1.M_Password = CO.ToString(txtPassword.Text);
             b1.M_UserFullName = CO.ToString(txtUserFullName.Text);
             b1.M_EmailId = CO.ToString(txtEmailId.Text);
             b1.M_InstituteId = CO.ToInt64(txtInstituteId.SelectedValue);
             b1.M_DepartmentId = CO.ToInt64(txtDepartmentId.SelectedValue);
             b1.M_DesignationId = CO.ToInt64(txtDesignationId.SelectedValue);
             b1.M_RollId = CO.ToInt64(txtRollId.SelectedValue);

            b1.UsersUpdate();              
            Response.Redirect("Users.aspx");
        }
        catch (Exception ex)
        {
            
        }
    }

   
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            b1.M_UserId = CO.ToInt64(lblMasterId.Text);
            b1.UsersDelete();
           Response.Redirect("Users.aspx");
        }
        catch (Exception ex)
        { 
        }
    }

   
    
}

