﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.IO;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    
    Requests_B r1 = new Requests_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void submit_Click(object sender, EventArgs e)
    {
        string fn =Session["id"]+ "addmission latter";
        string fl = "DOC/";
        string paths = System.IO.Path.Combine(fl,fn);
        AddmissionLetter.SaveAs(MapPath(paths));

        string fn2 = Session["id"] + "Idcard";
        string fl2 = "DOC/";
        string paths2 = System.IO.Path.Combine(fl2, fn2);
        Idcard.SaveAs(MapPath(paths));

        string fn3 = Session["id"] + "Marksheet";
        string fl3 = "DOC/";
        string paths3 = System.IO.Path.Combine(fl3, fn3);
        Marksheet.SaveAs(MapPath(paths));

        string fn4 = Session["id"] + "FeeRecipt";
        string fl4 = "DOC/";
        string paths4 = System.IO.Path.Combine(fl4, fn4);
        FeeRecipt.SaveAs(MapPath(paths));

        string fn5 = Session["id"] + "MedicalCerti";
        string fl5 = "DOC/";
        string paths5 = System.IO.Path.Combine(fl5, fn5);
        MedicalCerti.SaveAs(MapPath(paths));

        string fn6 = Session["id"] + "DeathCerti";
        string fl6 = "DOC/";
        string paths6 = System.IO.Path.Combine(fl6, fn6);
        DeathCerti.SaveAs(MapPath(paths));


        r1.M_AddmissionLetter = CO.ToString(fn);
        r1.M_IdentiyCard = CO.ToString(fn2);
        r1.M_Marksheet = CO.ToString(fn3);
        r1.M_FeeReceipt = CO.ToString(fn4);
        r1.M_MedicalCertificate = CO.ToString(fn5);
        r1.M_DeathCertificate = CO.ToString(fn6);
        r1.M_RequestId = CO.ToInt64(Request.QueryString["rid"]);

        r1.RequestsDOCUpdate();


        Response.Redirect("ChoiceFill.aspx?rid=" + Request.QueryString["rid"]);
    }
}