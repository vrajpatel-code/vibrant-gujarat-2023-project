using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class StudentsAdd : System.Web.UI.Page
{
    Students_B b1 = new Students_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
   
    protected void Page_Load(object sender, EventArgs e)
    {
	
    
        if (this.IsPostBack)
        {
            return;
        }
	
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
             b1.M_StudentName = CO.ToString(txtStudentName.Text);
             b1.M_InstitiuteId = CO.ToInt64(txtInstitiuteId.SelectedValue);
             b1.M_DepartmentId = CO.ToInt64(txtDepartmentId.SelectedValue);
             b1.M_Semester = CO.ToInt64(txtSemester.Text);
             b1.M_Year = CO.ToString(txtYear.Text);
             b1.M_Gender = CO.ToInt64(txtGender.Text);
             b1.M_EmailId = CO.ToString(txtEmailId.SelectedValue);
             b1.M_ContactNo = CO.ToString(txtContactNo.Text);
             b1.M_MeritNo = CO.ToString(txtMeritNo.Text);
             b1.M_Password = CO.ToString(txtPassword.Text);
            ds = b1.StudentsAdd();
            lblMasterId.Text = ds.Tables[0].Rows[0][0].ToString();
            Response.Redirect("Students.aspx");
        }
        catch (Exception ex)
        {
         
        }
        
    }

  
}

