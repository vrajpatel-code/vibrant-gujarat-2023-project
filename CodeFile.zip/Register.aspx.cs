﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;


public partial class Register : System.Web.UI.Page
{
    Students_B b1 = new Students_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            return;
        }
	
    }
    protected void SignUp_Click(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=students;Integrated Security=True");
        //con.Open();

        //SqlDataAdapter DA = new SqlDataAdapter("select * from Institutes  join InstituteDepartments  ON Institutes.InstituteId = InstituteDepartments.InstituteId where Institutes.InstituteName='" + InstitiuteId.Text + "' and InstituteDepartments.DepartmentName='" + DepartmentId.Text + "'", con);
        //DataTable dt = new DataTable();

        //DA.Fill(dt);

        
            b1.M_StudentName = CO.ToString(StudentName.Text);
            b1.M_EnrollNo = CO.ToString(EnrollNo.Text);
            b1.M_InstitiuteId = CO.ToInt64(InstitiuteId.SelectedValue);
            b1.M_DepartmentId = CO.ToInt64(DepartmentId.SelectedValue);
            
            b1.M_Semester = CO.ToInt64(Semester.Text);
            b1.M_Year = CO.ToString(Year.Text);
            b1.M_Gender = CO.ToInt64(Gender.SelectedValue);
            b1.M_EmailId = CO.ToString(EmailId.Text);
            b1.M_ContactNo = CO.ToString(ContactNo.Text);
            b1.M_MeritNo = CO.ToString(MeritNo.Text);
            b1.M_Password = CO.ToString(Password.Text);
            ds = b1.StudentsAdd();

            Response.Redirect("Login.aspx");
        


    }
}