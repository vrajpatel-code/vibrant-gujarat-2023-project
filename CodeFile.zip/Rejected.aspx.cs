﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Rejected : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (this.IsPostBack)
        {

            return;
        }
        int stid;

        if (Session["did"].ToString() == "1")
        {
            stid = 2;
        }
        else if (Session["did"].ToString() == "2")
        {
            stid = 4;
        }
        else if (Session["did"].ToString() == "3")
        {
            stid = 6;
        }
        else { stid = 1; }
        StID.Text = Convert.ToString(stid);
    }
}