﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ChoiceFill : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
        
        
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ;

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {

        
        

        SqlConnection con = new SqlConnection("Data Source=.\\sql2016;Initial Catalog=students;Integrated Security=True");
        con.Open();

        SqlDataAdapter DA = new SqlDataAdapter("select InstituteAddress, InstituteName,DepartmentName from Institutes  join InstituteDepartments  ON Institutes.InstituteId = InstituteDepartments.InstituteId where InstituteAddress='" + InstituteAddress.SelectedValue.ToString() + "' and InstituteName='"+Institute.SelectedValue.ToString()+"' and DepartmentName='"+Department.SelectedValue.ToString()+"'", con);
        DataTable dt = new DataTable();

        DA.Fill(dt);
        int i =0;
        foreach (System.Data.DataRow Row in dt.Rows)
        {
            string institute = "institute" + i.ToString();
            string department = "department" + i.ToString();
            string Address = "InstituteAddress" + i.ToString();
            Session[institute] = dt.Rows[i]["InstituteName"].ToString();
            Session[department] = dt.Rows[i]["DepartmentName"].ToString();
            Session[Address] = dt.Rows[i]["InstituteAddress"].ToString();
            

            Session["count"] = i;
            i++;
        }
        
       
        Response.Redirect("ChoiceFill.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["flag"] == null)
        {
            Session["flag"] = 0;
        }
        int i = Convert.ToInt16(Session["flag"].ToString());
        string str = Convert.ToString(i);
        Session["institute'"+str+"'"] = GridView1.SelectedRow.Cells[1].Text;
        Session["department'" + str + "'"] = GridView1.SelectedRow.Cells[2].Text;
        Session["Address'" + str + "'"] = GridView1.SelectedRow.Cells[0].Text;
        Session["flag"] = ++i;
        Response.Redirect("ChoiceFill.aspx");
        
    }
}