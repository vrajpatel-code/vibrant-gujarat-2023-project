using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class UsersAdd : System.Web.UI.Page
{
    Users_B b1 = new Users_B();
    Common CO = new Common();
    DataTable dt = new DataTable();
    DataSet ds = new DataSet();
    string PageName = "";
   
    protected void Page_Load(object sender, EventArgs e)
    {
	
    
        if (this.IsPostBack)
        {
            return;
        }
	
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
             b1.M_Username = CO.ToString(txtUsername.Text);
             b1.M_Password = CO.ToString(txtPassword.Text);
             b1.M_UserFullName = CO.ToString(txtUserFullName.Text);
             b1.M_EmailId = CO.ToString(txtEmailId.Text);
             b1.M_InstituteId = CO.ToInt64(txtInstituteId.SelectedValue);
             b1.M_DepartmentId = CO.ToInt64(txtDepartmentId.SelectedValue);
             b1.M_DesignationId = CO.ToInt64(txtDesignationId.SelectedValue);
             b1.M_RollId = CO.ToInt64(txtRollId.SelectedValue);

            ds = b1.UsersAdd();
            lblMasterId.Text = ds.Tables[0].Rows[0][0].ToString();
            Response.Redirect("Users.aspx");
        }
        catch (Exception ex)
        {
         
        }
        
    }

  
}

